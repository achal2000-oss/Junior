# desktop-assistant
JUNIOR the desktop-assistant.
Just run the code with the required modules installed and JUNIOR at your service.
Python version used 3.6.6 64-bit.
Required modules or packages : pyttsx3 , speech recognition , face recognition , opencv , dlib , pygame , pyaudio , numpy , wikipedia , rest used modules or packages are pre-installed in python3.

Commands currently accepting:-

time : it will tell you the time.

date : to know the date.

open chrome : to open chrome (first specify the chrome exe location in junior.py).

open code : to open VS code (first specify the code exe location in junior.py).

open youtube : to open YouTube.

open stackoverflow : to open stackoverflow.

play song or play music : to play random song from the directory with pause, resume, next, and exit options (Specify your song or music directory in junior.py).

joke : some random joke stuff.

news : top world news headlines.

news from INDIA or just INDIA news : news headlines from INDIA.

sports news : INDIAN sports news.

open google : to open google.

send gmail : to send gmail (you will be asked input whether to type or speak message and then input the message and then receiver's email address ).

hi or hello : for greeting message.

"Query" wikipedia : search something on wikipedia , for now it searches something unique or specific (remember to include wikipedia word).

sudoku solver : to have the solution of your Sudoku puzzle.

tic tac toe : to play Tic Tac Toe with your friend.

snake game : to play Snane Xenzia type game in your PC.

face recognition : to use the Face-Recognition Attendance System. It takes the classname as input and creates the csv file with the classname. The csv file will have the record of the students who are marked present. The csv file will be stored in the images folder. The images of students are also to be stored in the images folder (Remember to keep the image name as the name of the student).

All the queries asked will be saved in queries.txt .

All the jokes will be saved in jokes.txt .

All the top news headlines from world, India, and Indian sports news will be saved in news.txt, india_news.txt, and sports_news.txt respectively.

Snake game highscore will be saved in highscore.txt .

Tic tac toe information will be saved in tic_tac.txt .

Mail regarding information will be saved in mails.txt .

exit : exit the assistant.
